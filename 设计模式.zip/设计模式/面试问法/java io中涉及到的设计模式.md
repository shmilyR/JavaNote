1、适配器模式
2、装饰器模式

(http://blog.csdn.net/l_kanglin/article/details/60479378)