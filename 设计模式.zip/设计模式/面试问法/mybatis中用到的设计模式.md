1、工厂模式
2、构建者模式(Builder)
3、装饰器模式
4、模板模式
5、组合模式
6、外观模式
(http://blog.csdn.net/ashan_li/article/details/50358314)
